﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MainWindow : Window
    {
        private bool isDrawing = false;
        private Point startPoint;
        private Shape currentShape;
        private Brush currentBrush;
        private double currentThickness = 2;


        public MainWindow()
        {
            InitializeComponent();
            toolSelector.SelectionChanged += ToolSelector_SelectionChanged;
            thicknessSlider.ValueChanged += ThicknessSlider_ValueChanged;
            currentBrush = Brushes.Black;
        }
        private void ToolSelector_SelectionChanged(object sender, RoutedEventArgs e)
        {
            switch (toolSelector.SelectedIndex)
            {
                case 0:
                    currentShape = null; // Pen mode
                    break;
                case 1:
                    currentShape = new Line(); // Line mode
                    break;
                case 2:
                    currentShape = new Rectangle(); // Rectangle mode
                    break;
                case 3:
                    currentShape = new Ellipse(); // Ellipse mode
                    break;
                case 4:
                    currentShape = null; // Reset currentShape for "Draw Image" mode
                    DrawImage();
                    break;
            }
        }

        private void DrawImage()
        {
            // 이미지를 그리는 작업을 수행하는 코드를 추가
            // 예를 들어, OpenFileDialog를 통해 이미지를 선택하고 Canvas에 추가하는 작업 등을 수행
            // 이 코드는 이미지를 그리는 로직에 따라 달라질 수 있습니다.
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == true)
            {
                Image image = new Image();
                BitmapImage src = new BitmapImage();
                src.BeginInit();
                src.UriSource = new Uri(openFileDialog.FileName, UriKind.Relative);
                src.EndInit();
                image.Source = src;
                Canvas.SetLeft(image, startPoint.X);
                Canvas.SetTop(image, startPoint.Y);
                canvas.Children.Add(image);
            }
        }
        private void ThicknessSlider_ValueChanged(object sender, RoutedEventArgs e)
        {
            currentThickness = thicknessSlider.Value;
        }
        private void ColorPicker_SelectedColorChanged(object sender, RoutedEventArgs e)
        {
            currentBrush = new SolidColorBrush(colorPicker.SelectedColor);
        }

       

        private void Canvas_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDrawing && currentShape != null)
            {
                Point currentPoint = e.GetPosition(canvas);
                double width = Math.Abs(currentPoint.X - startPoint.X);
                double height = Math.Abs(currentPoint.Y - startPoint.Y);

                if (currentShape is Line line)
                {
                    line.X2 = currentPoint.X;
                    line.Y2 = currentPoint.Y;
                }
                else if (currentShape is Rectangle rectangle)
                {
                    rectangle.Width = width;
                    rectangle.Height = height;
                }
                else if (currentShape is Ellipse ellipse)
                {
                    ellipse.Width = width;
                    ellipse.Height = height;
                }
            }
        }

        private void Canvas_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            isDrawing = false;
            currentShape = null;
        }

        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            canvas.Children.Clear();
        }
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            // 코드는 이전 답변에서 사용한 것과 동일합니다.
        }
        private void Canvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (toolSelector.SelectedIndex == 4) // Assuming 4 is the index for the "Draw Image" tool
            {
                Image newImage = new Image();
                BitmapImage bi = new BitmapImage();
                bi.BeginInit();
                bi.UriSource = new Uri("path_to_your_image_file.jpg", UriKind.Relative);
                bi.EndInit();

                newImage.Source = bi;
                newImage.Width = 100; // Set the width of the image
                newImage.Height = 100; // Set the height of the image

                Point currentPoint = e.GetPosition(canvas);
                Canvas.SetLeft(newImage, currentPoint.X);
                Canvas.SetTop(newImage, currentPoint.Y);

                canvas.Children.Add(newImage);
            }
            else
                isDrawing = true;
            startPoint = e.GetPosition(canvas);
            if (currentShape != null)
            {
                currentShape.Stroke = currentBrush;
                currentShape.StrokeThickness = currentThickness;
                Canvas.SetLeft(currentShape, startPoint.X);
                Canvas.SetTop(currentShape, startPoint.Y);
                canvas.Children.Add(currentShape);
            }
        }

    }
}
